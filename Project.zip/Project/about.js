

document.addEventListener('click', event => {
    const current = event.target;

    // Check if the clicked element is a "Read More" button
    const isReadmoreBtn = current.classList.contains('read-more-btn');

    // Check if the clicked button is inside a read-more-container
    const isInReadMoreContainer = current.closest('.read-more-container');

    if (!isReadmoreBtn || !isInReadMoreContainer) return;

    // Find the container of the clicked button
    const parentContainer = isInReadMoreContainer;

    // Find the text to toggle inside the container
    const currentText = parentContainer.querySelector('.read-more-text');

    // Toggle the visibility of the text
    currentText.classList.toggle('read-more-text--show');

    // Toggle the button text based on text visibility
    current.textContent = currentText.classList.contains('read-more-text--show') ?
        "Read Less..." : "Read More...";
});