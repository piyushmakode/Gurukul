document.getElementById('editBtn').addEventListener('click', function() {
    document.getElementById('name').textContent = prompt('Enter your name:');
    document.getElementById('email').textContent = prompt('Enter your email:');
    document.getElementById('gender').textContent = prompt('Enter your gender:');
    document.getElementById('location').textContent = prompt('Enter your location:');
    document.getElementById('about').textContent = prompt('Enter about yourself:');
});
